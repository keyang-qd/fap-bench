# FAP-Bench

A compact benchmark suite for federated cross-sectional asset pricing. The code supports financially meaningful client partitions, controlled feature availability, partial client participation, centralized/local references, FedAvg, FedProx, SCAFFOLD, and FedAdam, together with predictive, portfolio, client-level, communication, and heterogeneity metrics.

## Data contract for the revised CRSP--Compustat recipe

The included `scripts/data_recipe2_revised.py` produces one row for a formation month `t` with:

- `formation_date` / `year_month`: feature-formation month;
- `target_date` / `target_year_month`: exact calendar month `t+1`;
- `retadj`: contemporaneous formation-month return;
- `retadj_1mn`: delisting-adjusted return realized in `t+1`;
- `sic` / `sic2`: industry identifiers;
- seven monthly cross-sectional profitability rank z-scores;
- `profitability_simple`: their deterministic average.

For this revised file, use:

```yaml
data:
  date_col: formation_date
  target_col: retadj_1mn
  target_shift_months: 0
  target_date_col: target_date

split:
  date_col: target_date

evaluation:
  date_col: target_date
```

Do **not** set `target_shift_months: 1` for data produced by the revised recipe, because the target is already aligned. The older 10-row sample used during schema inspection is different: its `retadj_1mn` is contemporaneous and therefore requires a one-month shift.

## Installation

```bash
cd code
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Generate the financial panel

Edit the input/output paths at the bottom of `scripts/data_recipe2_revised.py`, or call it directly:

```python
from scripts.data_recipe2_revised import data_recipe2

panel = data_recipe2(
    input_path="/Users/keyang/qdata",
    output_path="/Users/keyang/qdata/profitability_panel_revised.parquet",
)
```

The recipe:

- combines ordinary and delisting returns as `(1 + RET)(1 + DLRET) - 1`;
- never forward-fills returns, prices, dates, or market equity;
- carries forward Compustat fundamentals only;
- constructs exact calendar-month lags and targets;
- retains SIC and derives SIC2.

## Run the financial benchmark

Start from `configs/crsp_compustat_profitability.yaml`, replace `data.path`, and run:

```bash
python scripts/run_benchmark.py \
  --config configs/crsp_compustat_profitability.yaml
```

The production configuration maps four-digit SIC codes to the standard Fama--French 12 industries. Partition definitions, category collapsing, feature masks, and participating-client schedules use training clients only; validation/test periods cannot redefine the client population.

The seven component z-scores are used as model inputs. `profitability_simple` is intentionally omitted because retaining a deterministic composite while masking its components would weaken the feature-heterogeneity experiment.

## Feature heterogeneity

Set:

```yaml
feature_heterogeneity:
  enabled: true
  common_fraction: 0.5
  private_fraction: 0.5
```

Unavailable features are set to zero after monthly rank standardization. In this setting the output includes:

- `centralized_oracle`: centralized access to all seven features;
- `centralized_masked`: pooled training under the same client-specific feature masks;
- `local`, FedAvg, FedProx, SCAFFOLD, and FedAdam under those masks.

The matched centralized reference is the appropriate comparison for isolating the cost of federation; the oracle is only an information upper reference.

## Client optimization

The paper configuration uses SGD for all client updates:

```yaml
federated:
  client_optimizer: sgd
  client_lr: 0.01
  client_momentum: 0.0
```

SCAFFOLD is restricted to SGD in this implementation because applying its control-variate correction inside Adam is not the standard algorithm.

## Smoke tests

```bash
python scripts/make_synthetic.py \
  --output data/synthetic.parquet \
  --stocks 40 --months 24 --features 8

python scripts/run_benchmark.py \
  --config configs/synthetic_smoke.yaml

pytest -q
```

## Output files

- `source_validation.json`: target alignment, date consistency, universe, and industry checks;
- `heterogeneity.json`: measured client-size, distribution, feature, and participation heterogeneity;
- `partition_assignments.parquet`: formation/target dates and training-defined clients;
- `feature_masks.csv`: client-specific feature availability;
- `benchmark_results.csv`: consolidated method comparison;
- `training_<algorithm>.csv`: per-round loss and communication;
- `predictions_<method>.parquet`: stock-level out-of-sample predictions;
- `portfolio_returns_<method>.csv`: long--short returns dated by target realization month;
- `client_metrics_<method>.csv`: per-client predictive metrics.

## Remaining publication work

The code is an experimental benchmark implementation, not the finished empirical study. Before submission, select all hyperparameters using the validation period, run multiple seeds and rolling windows, verify the SCAFFOLD/FedAdam results against an established FL library on at least one setting, and document stock-price, microcap, liquidity, and transaction-cost filters.
